<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container .select2-selection--single {
        height: 37px !important;
        line-height: 35px !important;
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        line-height: 35px !important;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 38px;
    }

    table img {
        border-radius: 6px;
        object-fit: cover;
    }

    .table td,
    .table th {
        vertical-align: middle;
    }

    .ellipsis {
        white-space: nowrap;
        /* Không xuống dòng */
        overflow: hidden;
        /* Ẩn phần tràn ra */
        text-overflow: ellipsis;
        /* Hiện dấu "..." */
    }

    .border-dashed-long {
        border: 1px dashed transparent;
        border-image: repeating-linear-gradient(45deg, black 0, black 30px, transparent 10px, transparent 35px);
        border-image-slice: 1;
    }

    #drop-zone {
        cursor: pointer;
        border: 2px dashed #ccc;
        transition: border-color 0.3s;
    }

    #drop-zone.dragover {
        border-color: #007bff;
        background-color: #f0f8ff;
    }

    #preview img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #ddd;
    }
</style>

<?php
require_once '../includes/DBConnect.php';
$db = DBConnect::getInstance();

$categories = $db->select('SELECT * FROM categories');

$brands = $db->select('SELECT * FROM brand');

?>
<div>
    <div class="p-3 d-flex align-items-center rounded" style="background-color: #f0f0f0; height: 80px;">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalThemSanPham">
            <i class="fa-solid fa-plus me-1"></i>
            THÊM
        </button>

        <!-- Thanh tìm kiếm -->
        <div class="flex-grow-1">
            <form class="d-flex justify-content-center mx-auto" style="max-width: 400px; width: 100%;" role="search">
                <input class="form-control me-2" type="search" placeholder="Tìm kiếm..." aria-label="Search">
                <button type="submit" class="btn btn-sm p-0 border-0 bg-transparent">
                    <i class="fas fa-search fa-lg"></i>
                </button>
            </form>

        </div>
    </div>
    <!-- Tìm kiếm nâng cao -->
    <form method="GET" action=""
        class="d-flex gap-2 align-items-center container mt-3 flex-wrap justify-content-center">
        <input type="text" class="form-control w-auto" style="width: 180px;" name="keyword" placeholder="Tên sản phẩm">
        <input type="number" class="form-control w-auto" style="width: 120px;" name="price_min" placeholder="Giá từ">
        <input type="number" class="form-control w-auto" style="width: 120px;" name="price_max" placeholder="Giá đến">

        <select class="categorySearch form-select w-auto" style="width: 180px;" name="category">
            <option value="">Tất cả</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= $category['category_id'] ?>"><?= $category['name'] ?></option>
            <?php endforeach; ?>
        </select>

        <select class="brandSearch form-select w-auto" style="width: 180px; height: 100px;">
            <option value="">h</option>
            <?php foreach($brands as $brand): ?>
                <option value="<?= $brand['brand_id'] ?>"><?= $brand['name'] ?></option>
            <?php endforeach; ?>
        </select>
    </form>

    <div class="table-responsive mt-4 pe-3">
        <table class="table align-middle table-bordered">
            <thead class="table-light text-center">
                <tr>
                    <th scope="col">Mã SP</th>
                    <th scope="col">Hình ảnh</th>
                    <th scope="col">Tên</th>
                    <th scope="col">Giá bán</th>
                    <th scope="col">Thể loại</th>
                    <th scope="col">Thương hiệu</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Đơn vị đóng gói</th>
                    <th scope="col">Nơi sản xuất</th>
                    <th scope="col">Mô tả</th>
                    <th scope="col">Chức năng</th>
                </tr>
            </thead>
            <tbody class="text-center align-middle">
                <tr>
                    <td>1</td>
                    <td><img src="/assets/images/SanPham/-202211252250350400.jpg" alt="" class="img-fluid"
                            style="width: 75px; height: 75px; object-fit: cover;"></td>
                    <td class="ellipsis text-capitalize" style="max-width: 200px;">Lon coca cola không rõ nguồn gốc
                        do tôi sản xuất ra để lừa người ta</td>
                    <td class="fw-bold text-success">50,000</td>
                    <td>Nước ngọt</td>
                    <td>coca</td>
                    <td>100</td>
                    <td class="text-capitalize">lon</td>
                    <td class="text-capitalize">Việt Nam</td>
                    <td class="ellipsis" style="max-width: 150px;">Bia Tiger quen thuộc được kết hợp cùng rượu soju
                        dưa lưới vô cùng mới lạ, đảm bảo chính hãng bia Tiger nổi tiếng. Bia Tiger Soju Cheeky Plum
                        dưa lưới 330ml với 20% rượu soju, hương vị dưa lưới thơm ngon, mang đến trải nghiệm uống dễ
                        chịu, thích thú</td>
                    <td>
                        <a href="#" class="text-primary me-3"><i class="fas fa-pen fa-lg"></i></a>
                        <a href="#" class="text-danger"><i class="fas fa-trash fa-lg"></i></a>
                    </td>
                </tr>

                <!-- Thêm dòng khác tương tự -->
            </tbody>
        </table>
    </div>
    <div class="pagination-wrap">

    </div>
</div>
<!-- Modal thêm sản phẩm -->
<div class="modal fade" id="modalThemSanPham" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form class="modal-content" method="POST" action="add_product.php" enctype="multipart/form-data">
            <div class="modal-header">
                <h5 class="modal-title">Thêm sản phẩm mới</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label>Tên sản phẩm</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label>Size</label>
                        <input type="text" name="price" class="form-control" required>
                    </div>
                    <div class="col-md-6 d-flex flex-column">
                        <label>Loại sản phẩm</label>
                        <select class="category form-select">
                            <option value="1">Trà sữa</option>
                            <option value="2">Nước ngọt</option>
                            <option value="3">Cà phê</option>
                        </select>
                    </div>
                    <div class="col-md-6 d-flex flex-column">
                        <label>Thương hiệu</label>
                        <select class="brand form-select">
                            <option value="1">Pepsi</option>
                            <option value="2">Vinamilk</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label>Mô tả</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>

                    <div class="col-12 p-2">
                        <!-- Kéo thả ẩnh -->
                        <div id="drop-zone" class="border border-secondary border-dashed text-center p-4 rounded">
                            <div id="drop-message">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-2 text-muted"></i>
                                <p class="text-muted m-0">Kéo thả ảnh vào đây</p>
                            </div>

                            <!-- Nơi hiển thị tên file + nút xoá -->
                            <ul id="fileList" class="list-unstyled mt-3"></ul>

                            <div id="imagePreviewContainer" class="mt-3">
                                <img id="imagePreview" src="" alt="Xem ảnh" class="img-fluid rounded shadow"
                                    style="max-height: 300px; display: none;">
                            </div>

                            <!-- input ẩn, chỉ dùng để nhận file -->
                            <input type="file" id="fileInput" name="images[]" multiple hidden>
                        </div>
                        <input type="file" id="fileInputOutside" class="mt-2" multiple>
                    </div>

                    <div class="col-6">
                        <label>Đơn vị đóng gói</label>
                        <input type="text" class="form-control">
                    </div>

                    <div class="col-12">
                        <label>Kiểu đóng gói</label>
                        <table class="table align-middle table-bordered">
                            <thead class="table-light text-center">
                                <tr>
                                    <th scope="col">Tên kiểu đóng gói</th>
                                    <th scope="col">Số lượng trên đơn vị đóng gói</th>
                                    <th scope="col">Ảnh</th>
                                </tr>
                            </thead>
                            <tbody id="packagingBody">
                                <!-- khi click thêm thì thêm dòng mới ở đây -->
                                <tr id="addRowTrigger">
                                    <td colspan="3">
                                        <button class="btn btn-success" id="btnAddRow" type="button">
                                            <i class="fa-solid fa-circle-plus"></i>
                                            Thêm
                                        </button>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="submit" class="btn btn-success">Xác nhận thêm</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
            </div>
        </form>
    </div>
</div>





<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    // Kích hoạt tìm kiếm trong select
    $(document).ready(function() {
        $('.category').select2({
            placeholder: "Chọn loại sản phẩm",
            allowClear: true
        });
        // Kích hoạt Select2 cho brand (thương hiệu)
        $('.brand').select2({
            placeholder: "Chọn thương hiệu",
            allowClear: true
        });

        // Với select trong modal
        $('#modalThemSanPham .category').select2({
            placeholder: "Chọn loại sản phẩm",
            allowClear: true,
            dropdownParent: $('#modalThemSanPham') // đảm bảo hiển thị đúng trong modal
        });

        $('#modalThemSanPham .brand').select2({
            placeholder: "Chọn thương hiệu",
            allowClear: true,
            dropdownParent: $('#modalThemSanPham')
        });
    });

    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');
    const dropMessage = document.getElementById('drop-message');

    let currentFiles = []; // mảng chứa file đang được chọn

    // Hiệu ứng drag
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    // Kéo thả file
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        handleFiles(files);
    });

    // Ẩn hiển icon
    function updateDropMessage() {
        dropMessage.style.display = currentFiles.length > 0 ? 'none' : 'block';
    }

    // Xử lý file
    function handleFiles(files) {
        Array.from(files).forEach((file, index) => {
            if (!file.type.startsWith('image/')) return;

            currentFiles.push(file);

            const reader = new FileReader();
            reader.onload = function(e) {
                const li = document.createElement('li');
                li.innerHTML = `
        <a href="#" class="file-link text-primary text-decoration-underline" data-src="${e.target.result}">
          ${file.name}
        </a>
        <button type="button" class="btn btn-close" onclick="removeFile(${currentFiles.length - 1})"></button>
      `;
                fileList.appendChild(li);
            };

            reader.readAsDataURL(file); // Quan trọng!
        });

        updateDropMessage();
    }


    // Xoá file theo index
    function removeFile(index) {
        currentFiles.splice(index, 1);
        renderFileList();
        updateDropMessage();
    }

    // Cập nhật danh sách hiển thị lại
    function renderFileList() {
        fileList.innerHTML = '';
        currentFiles.forEach((file, idx) => {
            const li = document.createElement('li');
            li.innerHTML = `
  <a href="#" class="file-link text-primary text-decoration-underline me-1" data-src="${e.target.result}">
    ${file.name}
  </a>
  <button type="button" class="btn btn-close" onclick="removeFile(${currentFiles.length - 1})"></button>
`;
            fileList.appendChild(li);
        });
    }

    // Bắt sự kiện khi chọn ảnh bằng input ngoài
    document.getElementById('fileInputOutside').addEventListener('change', function() {
        handleFiles(this.files);
    });


    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('file-preview')) {
            e.preventDefault();

            const src = e.target.getAttribute('data-src');
            const img = document.createElement('img');
            img.src = src;
            img.alt = "Ảnh xem nhanh";
            img.style.maxHeight = '300px';
            img.style.marginTop = '10px';
            img.className = 'img-fluid rounded shadow';

            // Xoá ảnh cũ nếu có
            const oldPreview = document.getElementById('quick-preview');
            if (oldPreview) oldPreview.remove();

            // Thêm ảnh mới dưới danh sách
            img.id = 'quick-preview';
            document.getElementById('fileList').after(img);
        }
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('file-link')) {
            e.preventDefault();
            const imgSrc = e.target.getAttribute('data-src');
            const previewImg = document.getElementById('imagePreview');
            previewImg.src = imgSrc;
            previewImg.style.display = 'block';
        }
    });

    document.getElementById('btnAddRow').addEventListener('click', function() {
        const newRow = document.createElement('tr');
        newRow.innerHTML = `
            <td><input type="text" name="packaging_name[]" class="form-control" placeholder="Nhập kiểu đóng gói"></td>
            <td><input type="number" name="unit_quantity[]" class="form-control" placeholder="Số lượng"></td>
            <td><input type="file" name="packaging_image[]" class="form-control" accept="image/*"></td>
        `;

        const tbody = document.getElementById('packagingBody');
        const addRowTrigger = document.getElementById('addRowTrigger');
        tbody.insertBefore(newRow, addRowTrigger);
    });

    document.querySelector('.categorySearch').addEventListener('change', function() {
        const categoryId = this.value;
        fetch('ajax/get_brands_by_category.php?category_id=' + categoryId)
            .then(res => res.json())
            .then(brands => {
                const brandSelect = document.querySelector('.brandSearch');
                brands.forEach(brand => {
                    const option = document.createElement('option');
                    option.value = brand.brand_id;
                    option.textContent = brand.name;
                    brandSelect.appendChild(option);
                });
            });
    });
</script>