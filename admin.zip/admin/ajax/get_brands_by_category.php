<?php
require_once '../includes/DBConnect.php';
$db = DBConnect::getInstance();
$categoryId = $_GET['category_id'] ?? 1;

$sql = "SELECT DISTINCT b.brand_id, b.name
        FROM brand b
        JOIN products p ON b.brand_id = p.brand_id
        WHERE p.category_id = ?
";
$brands = $db->select($sql, [$categoryId]);

echo json_encode($brands);
